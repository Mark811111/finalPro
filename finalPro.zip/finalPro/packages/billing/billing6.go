package billing

import (
	"os"
)

type BillingData struct {
	CreateCustomer bool
	Purchase       bool
	Payout         bool
	Recurring      bool
	FraudControl   bool
	CheckoutPage   bool
}

func ReadBitMaskFromFile(filePath string) (uint8, error) {
	content, err := os.ReadFile(filePath)
	if err != nil {
		return 0, err
	}

	var mask uint8 = 0
	for i, bit := range content {
		if bit == '1' {
			mask |= 1 << (len(content) - 1 - i)
		}
	}

	return mask, nil
}

func ParseData(mask uint8) BillingData {
	return BillingData{
		CreateCustomer: mask&1 != 0,
		Purchase:       mask&2 != 0,
		Payout:         mask&4 != 0,
		Recurring:      mask&8 != 0,
		FraudControl:   mask&16 != 0,
		CheckoutPage:   mask&32 != 0,
	}
}
