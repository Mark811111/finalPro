package history

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type IncidentData struct {
	Topic  string `json:"topic"`
	Status string `json:"status"`
}

func GetIncidentHistory(filePath string) ([]IncidentData, error) {

	response, err := http.Get(filePath)
	if err != nil {
		return nil, fmt.Errorf("ошибка при выполнении GET запроса: %v", err)
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("ошибка: код ответа сервера %d", response.StatusCode)
	}

	var incidentData []IncidentData
	if err := json.NewDecoder(response.Body).Decode(&incidentData); err != nil {
		return nil, fmt.Errorf("ошибка при разборе JSON: %v", err)
	}

	return incidentData, nil
}
