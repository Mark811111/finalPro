package supportdata

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type SupportData struct {
	Topic         string `json:"topic"`
	ActiveTickets int    `json:"active_tickets"`
}

func GetSupportData(filePath string) ([]SupportData, error) {

	resp, err := http.Get(filePath)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusOK {

		var data []SupportData
		if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
			return nil, err
		}
		return data, nil
	} else if resp.StatusCode == 500 {

		return []SupportData{}, nil
	}

	return nil, fmt.Errorf("unexpected status code: %d", resp.StatusCode)
}
