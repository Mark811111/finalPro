package voicecalldata

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"

	"main.go/dictionaries"
)

type VoiceCallData struct {
	Country             string
	Bandwidth           int
	ResponseTime        int
	Provider            string
	ConnectionStability float32
	TTFB                int
	VoicePurity         int
	MedianOfCallsTime   int
}

func ReadVoiceCallDataFromFile(filePath string) ([]VoiceCallData, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("ошибка открытия файла: %v", err)
	}
	defer file.Close()

	var voiceCallData []VoiceCallData
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		data, err := ParseVoiceCallData(line)
		if err != nil {
			fmt.Printf("Пропускаю строку: %s. Ошибка: %v\n", line, err)
			continue
		}
		voiceCallData = append(voiceCallData, data)
	}

	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("ошибка чтения файла: %v", err)
	}

	return voiceCallData, nil
}

func ParseVoiceCallData(line string) (VoiceCallData, error) {
	parts := strings.Split(line, ";")
	if len(parts) != 8 {
		return VoiceCallData{}, fmt.Errorf("неверное количество полей в строке: %s", line)
	}

	provider := parts[3]
	if !IsValidProvider(provider) {
		return VoiceCallData{}, fmt.Errorf("недопустимый провайдер: %s", provider)
	}

	country := parts[0]
	bandwidth, _ := strconv.Atoi(parts[1])
	responseTime, _ := strconv.Atoi(parts[2])
	connectionStability, _ := strconv.ParseFloat(parts[4], 32)
	ttfb, _ := strconv.Atoi(parts[5])
	voicePurity, _ := strconv.Atoi(parts[6])
	medianOfCallsTime, _ := strconv.Atoi(parts[7])

	if !isValidCountry(country) {
		return VoiceCallData{}, fmt.Errorf("недопустимый код страны: %s", country)
	}

	return VoiceCallData{
		Country:             country,
		Bandwidth:           bandwidth,
		ResponseTime:        responseTime,
		Provider:            provider,
		ConnectionStability: float32(connectionStability),
		TTFB:                ttfb,
		VoicePurity:         voicePurity,
		MedianOfCallsTime:   medianOfCallsTime,
	}, nil
}

func IsValidProvider(provider string) bool {
	validProviders := map[string]bool{
		"TransparentCalls": true,
		"E-Voice":          true,
		"JustPhone":        true,
	}
	return validProviders[provider]
}

func isValidCountry(countryCode string) bool {
	_, exists := dictionaries.IsoCountries[countryCode]
	return exists
}
