package sms2

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"main.go/dictionaries"
)

type SMSData struct {
	Country      string
	Bandwidth    string
	ResponseTime string
	Provider     string
}

var validProviders map[string]bool

func init() {

	dir, err := os.Getwd()
	if err != nil {
		fmt.Println("Ошибка получения рабочей директории:", err)
		return
	}
	providersFilePath := filepath.Join(dir+"/packages/sms2/", "providers.json")

	fileContent, err := os.ReadFile(providersFilePath)
	if err != nil {
		fmt.Println("Ошибка чтения файла с провайдерами:", err)
		return
	}

	err = json.Unmarshal(fileContent, &validProviders)
	if err != nil {
		fmt.Println("Ошибка десериализации JSON:", err)
		return
	}
}

func CheckProvider(provider string) bool {
	_, exists := validProviders[provider]
	return exists
}

func ReadSMSData(filePath string) ([]SMSData, error) {
	fileContent, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	lines := strings.Split(string(fileContent), "\n")
	var smsData []SMSData

	for _, line := range lines {
		parts := strings.Split(line, ";")
		if len(parts) == 4 && dictionaries.IsoCountries[parts[0]] != "" && CheckProvider(parts[3]) {
			smsData = append(smsData, SMSData{
				Country:      parts[0],
				Bandwidth:    parts[1],
				ResponseTime: parts[2],
				Provider:     parts[3],
			})
		}
	}

	return smsData, nil
}
