package emaildata

import (
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"

	"main.go/dictionaries"
)

type EmailData struct {
	Country      string
	Provider     string
	DeliveryTime int
}

func IsValidProvider(provider string) bool {
	validProviders := map[string]bool{
		"Gmail": true, "Yahoo": true, "Hotmail": true, "MSN": true, "Orange": true,
		"Comcast": true, "AOL": true, "Live": true, "RediffMail": true, "GMX": true,
		"Protonmail": true, "Yandex": true, "Mail.ru": true,
	}
	_, exists := validProviders[provider]
	return exists
}

func ReadEmailDataFromFile(filePath string) ([]EmailData, error) {
	file, err := os.Open(filePath)
	if err != nil {
		return nil, fmt.Errorf("ошибка при открытии файла: %v", err)
	}
	defer file.Close()

	var emailData []EmailData
	reader := io.Reader(file)

	content, err := io.ReadAll(reader)
	if err != nil {
		return nil, fmt.Errorf("ошибка при чтении файла: %v", err)
	}

	lines := strings.Split(string(content), "\n")
	for _, line := range lines {
		data, err := ParseEmailData(line)
		if err != nil {
			fmt.Printf("Ошибка при разборе строки: %v\n", err)
			continue
		}
		emailData = append(emailData, data)
	}

	return emailData, nil
}

func ParseEmailData(line string) (EmailData, error) {
	parts := strings.Split(line, ";")
	if len(parts) != 3 {
		return EmailData{}, fmt.Errorf("неверное количество полей в строке")
	}

	countryCode, provider, deliveryTimeStr := parts[0], parts[1], parts[2]
	if !IsValidCountry(countryCode) {
		return EmailData{}, fmt.Errorf("недопустимый код страны: %s", countryCode)
	}

	if !IsValidProvider(provider) {
		return EmailData{}, fmt.Errorf("недопустимый провайдер: %s", provider)
	}

	deliveryTime, err := strconv.Atoi(deliveryTimeStr)
	if err != nil {
		return EmailData{}, fmt.Errorf("ошибка преобразования времени доставки в число: %v", err)
	}

	return EmailData{
		Country:      countryCode,
		Provider:     provider,
		DeliveryTime: deliveryTime,
	}, nil
}

func IsValidCountry(countryCode string) bool {
	_, exists := dictionaries.IsoCountries[countryCode]
	return exists
}
