package api

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/mux"
	"main.go/packages/dataProcessor"
	"main.go/packages/handlers"
)

func HandleConnection(w http.ResponseWriter, r *http.Request) {

	resultSet, err := dataProcessor.GetResultData()
	var response handlers.ResultT

	if err != nil {

		response.Status = false
		response.Error = "Error on collect data"
	} else {

		response.Status = true
		response.Data = resultSet
	}

	jsonResponse, jsonErr := json.Marshal(response)
	if jsonErr != nil {
		log.Printf("Error marshalling JSON: %v", jsonErr)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	fmt.Fprint(w, string(jsonResponse))
}

func StartServer() {
	r := mux.NewRouter()
	r.HandleFunc("/", HandleConnection).Methods("GET")

	srv := &http.Server{
		Handler: r,
		Addr:    "127.0.0.1:8282",
	}

	log.Println("Server is starting on :8282")
	if err := srv.ListenAndServe(); err != nil {
		log.Fatal("Error starting server: ", err)
	}
}
