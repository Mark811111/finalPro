package handlers

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/gorilla/mux"
	"main.go/packages/dataProcessor"
)

type ResultT struct {
	Status bool        `json:"status"`
	Data   interface{} `json:"data,omitempty"`
	Error  string      `json:"error,omitempty"`
}

func HandleConnection(w http.ResponseWriter, r *http.Request) {

	var result ResultT

	resultSet, err := dataProcessor.GetResultData()
	if err != nil {

		result.Status = false
		result.Error = "Error on collect data"
	} else {

		if resultSet.SMS != nil && resultSet.MMS != nil && resultSet.VoiceCall != nil {
			result.Status = true
			result.Data = resultSet
		} else {
			result.Status = false
			result.Error = "Error on collect data"
		}
	}

	jsonResponse, jsonErr := json.Marshal(result)
	if jsonErr != nil {
		log.Fatal("Error marshalling JSON: ", jsonErr)
		return
	}

	w.Header().Set("Content-Type", "application/json")

	fmt.Fprint(w, string(jsonResponse))
}

func StartServer() {
	r := mux.NewRouter()

	r.HandleFunc("/", HandleConnection).Methods("GET")

	srv := &http.Server{
		Handler: r,
		Addr:    "127.0.0.1:8282",
	}

	log.Println("Starting server on :8282")
	if err := srv.ListenAndServe(); err != nil {
		log.Fatal("ListenAndServe error: ", err)
	}
}
