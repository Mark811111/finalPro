package pathsloader

import (
	"encoding/json"
	"os"
)

type Paths struct {
	SMS       string `json:"sms"`
	MMS       string `json:"mms"`
	VoiceCall string `json:"voice"`
	Email     string `json:"email"`
	Billing   string `json:"billing"`
	Support   string `json:"support"`
	Incidents string `json:"incidents"`
}

func LoadFromFile(filePath string) (Paths, error) {
	var paths Paths

	fileData, err := os.ReadFile(filePath)
	if err != nil {
		return paths, err
	}

	if err := json.Unmarshal(fileData, &paths); err != nil {
		return paths, err
	}

	return paths, nil
}
