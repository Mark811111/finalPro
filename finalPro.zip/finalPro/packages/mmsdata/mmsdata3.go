package mmsdata

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"main.go/dictionaries"
)

type MMSData struct {
	Country      string `json:"country"`
	Provider     string `json:"provider"`
	Bandwidth    string `json:"bandwidth"`
	ResponseTime string `json:"response_time"`
}

func GetMMSData(filePath string) ([]MMSData, error) {

	response, err := http.Get(filePath)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()

	if response.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("unexpected status code: %d", response.StatusCode)
	}

	body, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}

	var result []MMSData
	err = json.Unmarshal(body, &result)
	if err != nil {
		return nil, err
	}

	var filteredData []MMSData
	for _, data := range result {
		if dictionaries.IsoCountries[data.Country] != "" && isValidProvider(data.Provider) {
			filteredData = append(filteredData, data)
		}
	}

	return filteredData, nil
}

func isValidProvider(provider string) bool {

	validProviders := map[string]bool{
		"Topolo": true,
		"Rond":   true,
		"Kildy":  true,
	}
	return validProviders[provider]
}
