package dataProcessor

import (
	"fmt"
	"log"
	"sort"

	"main.go/dictionaries"
	"main.go/packages/billing"
	"main.go/packages/emaildata"
	"main.go/packages/history"
	"main.go/packages/mmsdata"
	"main.go/packages/pathsloader"
	"main.go/packages/sms2"
	"main.go/packages/supportdata"
	"main.go/packages/voicecalldata"
)

type ResultSetT struct {
	SMS       [][]sms2.SMSData
	MMS       [][]mmsdata.MMSData
	VoiceCall []voicecalldata.VoiceCallData
	Email     map[string][][]emaildata.EmailData
	Billing   uint8
	Support   [2]int
	Incidents []history.IncidentData
}

func GetResultData() (ResultSetT, error) {
	paths, err := pathsloader.LoadFromFile("/media/misha/gopet/finalPro/packages/pathsloader/pathway.json")
	if err != nil {
		log.Fatalf("Не удалось загрузить конфигурацию путей: %v", err)
	}

	smsData, err := sms2.ReadSMSData(paths.SMS)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных SMS: %v", err)
	}

	processedSMSData := ProcessSMSData(smsData)

	mmsData, err := mmsdata.GetMMSData(paths.MMS)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных MMS: %v", err)
	}

	processedMMSData := ProcessMMSData(mmsData)

	voiceCallData, err := voicecalldata.ReadVoiceCallDataFromFile(paths.VoiceCall)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных VoiceCall: %v", err)
	}

	emailData, err := emaildata.ReadEmailDataFromFile(paths.Email)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных Email: %v", err)
	}

	processedEmailData := ProcessEmailData(emailData)

	billingData, err := billing.ReadBitMaskFromFile(paths.Billing)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных Billing: %v", err)
	}

	supportData, err := supportdata.GetSupportData(paths.Support)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных Support: %v", err)
	}

	supportLoad := ProcessSupportData(supportData)

	incidentData, err := history.GetIncidentHistory(paths.Incidents)
	if err != nil {
		return ResultSetT{}, fmt.Errorf("ошибка при чтении данных Incident: %v", err)
	}

	processedIncidentData := ProcessIncidentData(incidentData)

	Result := ResultSetT{
		SMS:       processedSMSData,
		MMS:       processedMMSData,
		VoiceCall: voiceCallData,
		Email:     processedEmailData,
		Billing:   billingData,
		Support:   supportLoad,
		Incidents: processedIncidentData,
	}

	return Result, nil
}

func ProcessSMSData(smsData []sms2.SMSData) [][]sms2.SMSData {

	for i := range smsData {
		smsData[i].Country = dictionaries.IsoCountries[smsData[i].Country]
	}

	providerSorted := make([]sms2.SMSData, len(smsData))
	copy(providerSorted, smsData)
	sort.Slice(providerSorted, func(i, j int) bool {
		return providerSorted[i].Provider < providerSorted[j].Provider
	})

	countrySorted := make([]sms2.SMSData, len(smsData))
	copy(countrySorted, smsData)
	sort.Slice(countrySorted, func(i, j int) bool {
		return countrySorted[i].Country < countrySorted[j].Country
	})

	sortedData := [][]sms2.SMSData{providerSorted, countrySorted}

	return sortedData
}

func ProcessMMSData(rawMMSData []mmsdata.MMSData) [][]mmsdata.MMSData {

	for i := range rawMMSData {
		rawMMSData[i].Country = dictionaries.IsoCountries[rawMMSData[i].Country]
	}

	dataSortedByProvider := make([]mmsdata.MMSData, len(rawMMSData))
	copy(dataSortedByProvider, rawMMSData)

	dataSortedByCountry := make([]mmsdata.MMSData, len(rawMMSData))
	copy(dataSortedByCountry, rawMMSData)

	sort.Slice(dataSortedByProvider, func(i, j int) bool {
		return dataSortedByProvider[i].Provider < dataSortedByProvider[j].Provider
	})

	sort.Slice(dataSortedByCountry, func(i, j int) bool {
		return dataSortedByCountry[i].Country < dataSortedByCountry[j].Country
	})

	sortedData := [][]mmsdata.MMSData{dataSortedByProvider, dataSortedByCountry}

	return sortedData
}

func ProcessEmailData(emailData []emaildata.EmailData) map[string][][]emaildata.EmailData {
	fmt.Println("Processing email data...")

	result := make(map[string][][]emaildata.EmailData)

	allEmailData := emailData

	sort.SliceStable(allEmailData, func(i, j int) bool {
		return allEmailData[i].DeliveryTime < allEmailData[j].DeliveryTime
	})

	var fastEmailProviders, slowEmailProviders []emaildata.EmailData
	if len(allEmailData) > 3 {
		fastEmailProviders = allEmailData[:3]
		slowEmailProviders = allEmailData[len(allEmailData)-3:]
	} else {
		fastEmailProviders = allEmailData
		slowEmailProviders = allEmailData
	}

	result["all"] = [][]emaildata.EmailData{fastEmailProviders, slowEmailProviders}

	return result
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func ProcessBillingData(billingData billing.BillingData) {
	fmt.Println("Processing billing data...")

}

func ProcessSupportData(supportData []supportdata.SupportData) [2]int {
	fmt.Println("Processing support data...")

	ticketCount := len(supportData)
	avgTicketTime := 60 / 18

	var load int
	if ticketCount <= 9 {
		load = 1
	} else if ticketCount <= 16 {
		load = 2
	} else {
		load = 3
	}

	waitTime := ticketCount * avgTicketTime

	return [2]int{load, waitTime}
}

func ProcessIncidentData(incidentData []history.IncidentData) []history.IncidentData {
	fmt.Println("Processing incident data...")

	activeIncidents := make([]history.IncidentData, 0)
	sortedIncidents := make([]history.IncidentData, 0)

	for _, incident := range incidentData {
		if incident.Status == "active" {
			activeIncidents = append(activeIncidents, incident)
		} else {
			sortedIncidents = append(sortedIncidents, incident)
		}
	}

	sortedIncidents = append(activeIncidents, sortedIncidents...)

	return sortedIncidents
}
