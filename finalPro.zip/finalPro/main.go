package main

import (
	//"fmt"
	"log"
	"net/http"

	//"main.go/packages/dataProcessor"
	"main.go/packages/handlers"
)

func main() {

	//fmt.Println(dataProcessor.GetResultData())

	http.HandleFunc("/", handlers.HandleConnection)

	log.Println("Server starting on http://localhost:8282...")
	if err := http.ListenAndServe(":8282", nil); err != nil {
		log.Fatalf("Error starting server: %s\n", err)
	}

}
