package dictionaries

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
)

var IsoCountries map[string]string
var fileName string = "dictionaries/countries.json"

func LoadCountriesFromJSON() error {
	// Получаем текущую рабочую директорию
	dir, err := os.Getwd()
	if err != nil {
		return fmt.Errorf("error getting current directory: %v", err)
	}

	// Объединяем путь текущей директории с именем файла
	filePath := filepath.Join(dir, fileName)

	// Читаем содержимое файла
	bytes, err := os.ReadFile(filePath)
	if err != nil {
		return fmt.Errorf("error reading JSON file: %v", err)
	}

	// Десериализуем JSON в карту
	if err := json.Unmarshal(bytes, &IsoCountries); err != nil {
		return fmt.Errorf("error unmarshalling JSON: %v", err)
	}

	return nil
}

func init() {
	// Попытка загрузить данные при инициализации пакета
	err := LoadCountriesFromJSON()
	if err != nil {
		log.Fatalf("Failed to load countries from JSON: %v", err)
	}
}
